"""NeuralCloud Harness visualization GUI."""
