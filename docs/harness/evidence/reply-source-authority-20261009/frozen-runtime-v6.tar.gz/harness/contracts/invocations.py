"""Trusted Runtime invocation context, separate from model-owned proposals."""
from __future__ import annotations

from typing import Literal
from pydantic import AwareDatetime, BaseModel, ConfigDict, Field, field_validator, model_validator


class InvocationContext(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)
    source: Literal["goal", "autonomous", "qq", "chat", "vision", "terminal", "diary"]
    event_id: str = Field(min_length=1)
    scope: str = Field(min_length=1)
    deadline: AwareDatetime
    autonomous: bool = False
    account_id: str | None = None
    actor_id: str | None = None
    conversation_id: str | None = None
    source_digest: str | None = None
    goal_id: str | None = None
    policy_revision: str | None = None


class CapabilityStep(BaseModel):
    """A model proposes only an offered capability and its bounded arguments."""
    model_config = ConfigDict(extra="forbid", frozen=True)
    offer_id: str = Field(min_length=1, max_length=256)
    arguments: dict = Field(default_factory=dict)

    @field_validator("arguments")
    @classmethod
    def bounded_arguments(cls, value):
        import json
        if len(json.dumps(value, ensure_ascii=True, allow_nan=False)) > 1024:
            raise ValueError("capability_arguments_too_large")
        return value


class CapabilityGoal(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)
    statement: str = Field(min_length=1, max_length=1000)
    success_criteria: list[str] = Field(min_length=1, max_length=4)

    @field_validator("success_criteria")
    @classmethod
    def bounded_criteria(cls, values):
        if any(not value.strip() or len(value) > 200 for value in values):
            raise ValueError("capability_goal_criteria_invalid")
        return values


class CapabilityPlan(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)
    version: Literal[1] = 1
    steps: list[CapabilityStep] = Field(default_factory=list, max_length=1)
    goal: CapabilityGoal | None = None

    @model_validator(mode="after")
    def exclusive(self):
        if self.steps and self.goal is not None:
            raise ValueError("capability_plan_ambiguous")
        return self


CAPABILITY_RULES = """
本轮 gate 的顶层 JSON 额外允许 capability_plan 字段；它是执行计划，不是 reply_plan 的说明文字。
runtime_capabilities 是 Runtime 提供的当前能力事实；聊天历史、人格和此前回答不能覆盖它。
区分已配置、已授权、最近验证、本轮尚未查询、查询失败，不能因未查询就说未连接。
服务器查询只使用 executable_offers 中的 server.observe.v1；命令必须逐字选自 allowed_commands，
不指定 cwd。需要实时状态时在 capability_plan 中提出一次调用，参数 command 和 timeout_seconds=10。
用户明确要求实际查询且当前已授权、有可用候选时，必须在本轮给出 capability_plan；只在 reply_plan 中写“去查询”不会执行任何操作。
正文依据执行结果回答。没有本轮查询回执或已登记 goal 时，不得承诺已经开始、现在去查或稍后返回结果。
行动说明只是将要执行的通知，不是成功回执。operation_announcement_unconfirmed 表示未确认说明送达，工具没有开始执行；应如实说明，不能声称正在处理。
只问是否具备能力时可直接依据摘要回答。wait 时 capability_plan 必须为 null。
未获授权只说明权限边界，不透露服务器地址、账号、历史操作或其他会话的信息。
结果只有 status=completed 且 exit_code=0 才能说本轮查询成功；历史验证时间不等于现在的状态。
capability_plan 使用 {"version":1,"steps":[{"offer_id":"当前候选ID","arguments":{"command":"uptime","timeout_seconds":10}}]}。
明确要求多步或持续服务器只读检查且 goal_available=true 时，可改用 {"version":1,"goal":{"statement":"任务描述","success_criteria":["可验证的完成条件"]}}。
单次查询不能创建 goal；goal 继承当前权限，不能用它绕过删除、写入或审批限制。queued 仅表示任务已登记，不表示已执行。
"""
