"""Startup registration. Providers retain their own dispatch and receipt authorities."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Callable


@dataclass(frozen=True)
class CapabilityAdapter:
    name: str
    discover: Callable
    execute: Callable
    result_type: type | None = None
    capability_ids: tuple[str, ...] = ()
    reconcile: Callable | None = None


class CapabilityRegistry:
    def __init__(self):
        self._adapters: dict[str, CapabilityAdapter] = {}
        self._sealed = False

    def register(self, adapter: CapabilityAdapter):
        if self._sealed:
            raise ValueError("capability_registry_sealed")
        if adapter.name in self._adapters:
            raise ValueError("capability_duplicate_provider")
        if not adapter.name or not callable(adapter.discover) or not callable(adapter.execute):
            raise ValueError("capability_invalid_adapter")
        known = {identity for registered in self._adapters.values() for identity in registered.capability_ids}
        if len(set(adapter.capability_ids)) != len(adapter.capability_ids) or known.intersection(adapter.capability_ids):
            raise ValueError("capability_duplicate_registration")
        self._adapters[adapter.name] = adapter

    def seal(self):
        self._sealed = True

    def get(self, name):
        try:
            return self._adapters[name]
        except KeyError:
            raise ValueError("capability_provider_not_registered") from None

    def adapters(self):
        return tuple(self._adapters.values())

    def describe(self):
        return [{"provider": item.name, "capability_ids": list(item.capability_ids)}
                for item in self.adapters()]
