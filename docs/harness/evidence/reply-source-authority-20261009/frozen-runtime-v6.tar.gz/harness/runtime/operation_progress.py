"""Durable, channel-independent announcement barrier for user-requested work.

An announcement is a delivery fact, never evidence that an operation succeeded.
Adapters may publish a frozen notice, but only verified delivery releases work.
"""
from __future__ import annotations

import asyncio
from contextlib import closing
from datetime import datetime, timedelta
import hashlib
import json
import os
import sqlite3
from weakref import WeakValueDictionary

from harness.runtime.models import utc_now, RuntimeLifecycle


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


class ProgressStore:
    def __init__(self, path):
        self.path = path
        path.parent.mkdir(parents=True, exist_ok=True)
        with closing(self.connect()) as db, db:
            db.execute("CREATE TABLE IF NOT EXISTS operations(id TEXT PRIMARY KEY, binding TEXT NOT NULL, record TEXT NOT NULL)")
        os.chmod(path, 0o600)

    def connect(self):
        return sqlite3.connect(self.path, timeout=5)

    def get(self, identity):
        with closing(self.connect()) as db:
            row = db.execute("SELECT record FROM operations WHERE id=?", (identity,)).fetchone()
        return json.loads(row[0]) if row else None

    def begin(self, identity, binding, source, text, deadline):
        row = {"id": identity, "source": source, "status": "announcing", "goal_id": None,
               "created_at": utc_now().isoformat(),
               "notices": [{"id": identity + ":started", "purpose": "operation_started", "text": text,
                            "deadline": deadline.isoformat()}]}
        digest = hashlib.sha256(canonical([binding, source, text]).encode()).hexdigest()
        with closing(self.connect()) as db, db:
            db.execute("BEGIN IMMEDIATE")
            old = db.execute("SELECT binding FROM operations WHERE id=?", (identity,)).fetchone()
            if old and old[0] != digest:
                raise ValueError("operation_progress_binding_changed")
            if not old:
                db.execute("INSERT INTO operations VALUES(?,?,?)", (identity, digest, canonical(row)))
        return self.get(identity)

    def update(self, identity, **changes):
        with closing(self.connect()) as db, db:
            db.execute("BEGIN IMMEDIATE")
            row = json.loads(db.execute("SELECT record FROM operations WHERE id=?", (identity,)).fetchone()[0])
            row.update(changes)
            db.execute("UPDATE operations SET record=? WHERE id=?", (canonical(row), identity))
        return row

    def pending_goals(self):
        with closing(self.connect()) as db:
            return [json.loads(r[0]) for r in db.execute("SELECT record FROM operations WHERE json_extract(record,'$.goal_id') IS NOT NULL AND json_extract(record,'$.status')='queued'")]

    def recover(self):
        # Only the new owning Runtime calls this after the previous process has
        # stopped. An acknowledged action interrupted before its recorded result
        # must not turn into permission to execute again.
        with closing(self.connect()) as db, db:
            rows = [json.loads(r[0]) for r in db.execute("SELECT record FROM operations WHERE json_extract(record,'$.status')='announced'")]
            for row in rows:
                row["status"] = "interrupted"
                if row["source"]["channel"] == "qq":
                    row["notices"].append({"id": row["id"] + ":result", "purpose": "operation_result",
                        "text": "这次处理被中断，尚未确认完整结果；不会自动重复执行。",
                        "deadline": None})
                db.execute("UPDATE operations SET record=? WHERE id=?", (canonical(row), row["id"]))

    def interrupted(self):
        with closing(self.connect()) as db:
            return [json.loads(r[0]) for r in db.execute("SELECT record FROM operations WHERE json_extract(record,'$.status')='interrupted' AND json_extract(record,'$.source.channel')='qq'")]

    def summaries(self, limit=50):
        with closing(self.connect()) as db:
            rows = [json.loads(r[0]) for r in db.execute("SELECT record FROM operations ORDER BY rowid DESC LIMIT ?", (min(200, max(1, limit)),))]
        return [{"id": r["id"], "channel": r["source"]["channel"], "event_id": r["source"]["event_id"],
                 "status": r["status"], "goal_id": r["goal_id"], "created_at": r["created_at"],
                 "announcement_delivery": r.get("delivery"), "result_delivery": r.get("result_delivery")} for r in rows]


class OperationProgress:
    def __init__(self, supervisor):
        self.supervisor = supervisor
        self.store = ProgressStore(supervisor.state_dir / "operation-progress.sqlite3")
        self._locks = WeakValueDictionary()
        supervisor.add_listener(self.on_event)

    def enabled(self):
        from harness.runtime.capability_adapters import get_broker
        return get_broker(self.supervisor).policy.read()[0].progress_enabled

    def bridge(self):
        from harness.qq.direct_capabilities import QQCapabilityTransports
        bridge = getattr(self.supervisor, "qq_capability_bridge", None)
        return bridge.direct if isinstance(bridge, QQCapabilityTransports) else bridge

    async def announce(self, identity, *, source, binding, text, deadline, guard=None):
        lock = self._locks.setdefault(identity, asyncio.Lock())
        async with lock:
            return await self._announce(identity, source=source, binding=binding, text=text, deadline=deadline, guard=guard)

    async def _announce(self, identity, *, source, binding, text, deadline, guard=None):
        if not self.enabled():
            return True
        row = self.store.begin(identity, binding, source, text, min(deadline, utc_now() + timedelta(seconds=8)))
        if row["status"] != "announcing":
            return row["status"] not in {"unannounced", "uncertain", "interrupted"}
        notice = row["notices"][0]
        while utc_now() < datetime.fromisoformat(notice["deadline"]):
            try:
                if self.supervisor.lifecycle != RuntimeLifecycle.RUNNING or guard and guard():
                    break
            except (ValueError, OSError):
                break
            if source["channel"] == "chat":
                # WebSocket publication acknowledges enqueue to the UI stream,
                # not human reading; the UI renders it separately from answers.
                await self.supervisor._publish("operation.progress", {"id": notice["id"], "event_id": source["event_id"], "text": text})
                self.store.update(identity, status="announced", delivery={"status": "published"})
                return True
            bridge = self.bridge()
            if bridge is None or not callable(getattr(bridge, "publish_operation_notice", None)):
                break
            try:
                result = await asyncio.to_thread(bridge.publish_operation_notice, row, notice)
            except (ValueError, OSError, sqlite3.Error):
                break
            if result["status"] == "delivered":
                self.store.update(identity, status="announced", delivery=result)
                return True
            if result["status"] in {"cancelled", "unknown"}:
                break
            await asyncio.sleep(.1)
        self.store.update(identity, status="unannounced")
        return False

    def finish(self, identity, result):
        row = self.store.get(identity)
        if row is None or row["status"] in {"unannounced", "uncertain", "interrupted"}:
            return
        self.store.update(identity, status="queued" if (result or {}).get("goal_id") else "finished",
                          goal_id=(result or {}).get("goal_id"), result=result)

    async def on_event(self, topic, payload):
        if topic != "event.completed" or self.supervisor.lifecycle != RuntimeLifecycle.RUNNING or not self.enabled():
            return
        for action in ("web", "server"):
            identity = "operation:" + str(payload.get("event_id")) + ":" + action
            if self.store.get(identity):
                self.finish(identity, {"status": "response_processed"})
        for row in self.store.interrupted():
            if (row.get("result_delivery") or {}).get("status") in {"delivered", "cancelled"}:
                continue
            bridge = self.bridge()
            if bridge is None:
                continue
            notice = next(n for n in row["notices"] if n["purpose"] == "operation_result")
            if notice["deadline"] is None:
                notice["deadline"] = (utc_now() + timedelta(seconds=120)).isoformat()
                row = self.store.update(row["id"], notices=row["notices"])
            try:
                result = await asyncio.to_thread(bridge.publish_operation_notice, row, notice)
                if result["status"] in {"delivered", "cancelled", "unknown"}:
                    # Keep interrupted as the execution barrier, even after the
                    # informational message has a receipt.
                    self.store.update(row["id"], result_delivery=result)
            except (ValueError, OSError, sqlite3.Error):
                continue
        # Goal effects are owned by the existing goal controller. This observer
        # only reports terminal state and never resumes/re-executes the goal.
        for row in self.store.pending_goals():
            goal = self.supervisor.goals.store.get("goal", row["goal_id"])
            if not goal or goal["status"] not in {"completed", "abandoned", "cancelled", "failed"}:
                continue
            if goal.get("invocation_context"):
                from harness.contracts.invocations import InvocationContext
                from harness.runtime.capability_adapters import get_broker
                context = InvocationContext.model_validate(goal["invocation_context"])
                policy, _ = get_broker(self.supervisor).policy.read()
                if not policy.server_authorized(context):
                    self.store.update(row["id"], status="finished", result_delivery={"status": "cancelled"})
                    continue
            notice = next((n for n in row["notices"] if n["purpose"] == "operation_result"), None)
            if notice is None:
                label = "已完成" if goal["status"] == "completed" else "未完成，任务已停止"
                text = "之前委托的任务" + label + "：" + goal["statement"][:400]
                calls = getattr(getattr(self.supervisor, "capabilities", None), "calls", None)
                server = getattr(self.supervisor, "server", None)
                if calls is not None and server is not None:
                    rows = [r for r in calls.all() if r.get("goal_binding", {}).get("goal_id") == row["goal_id"]
                            and r.get("status") == "completed" and r.get("server_call_id")]
                    outputs = []
                    for result in rows[-3:]:
                        receipt = server.calls.command(result["server_call_id"])
                        if receipt and receipt["status"] == "completed" and receipt.get("result"):
                            data = json.loads(receipt["result"])
                            if data.get("exit_code") == 0 and data.get("stdout"):
                                outputs.append(data["stdout"][:600])
                    if outputs:
                        text += "\n已核验的查询输出：\n" + "\n".join(outputs)
                notice = {"id": row["id"] + ":result", "purpose": "operation_result",
                          "text": text,
                          "deadline": (utc_now() + timedelta(seconds=120)).isoformat()}
                row = self.store.update(row["id"], notices=[*row["notices"], notice])
            bridge = self.bridge()
            if bridge is not None:
                try:
                    result = await asyncio.to_thread(bridge.publish_operation_notice, row, notice)
                    if result["status"] in {"delivered", "cancelled", "unknown"}:
                        self.store.update(row["id"], status="finished", result_delivery=result)
                except (ValueError, OSError, sqlite3.Error):
                    continue


def get_progress(supervisor):
    value = getattr(supervisor, "operation_progress", None)
    if value is None:
        supervisor.operation_progress = value = OperationProgress(supervisor)
    return value


async def announce_chat(supervisor, event, action, deadline, *, guard=None):
    from harness.runtime.capability_adapters import get_broker
    if not get_broker(supervisor).policy.read()[0].progress_enabled:
        return True
    text = "我先" + {"server": "查询服务器状态", "web": "查找资料"}[action] + "，有结果后再回复你。"
    return await get_progress(supervisor).announce("operation:" + event.event_id + ":" + action,
        source={"channel": "chat", "event_id": event.event_id}, binding=[event.event_id, action],
        text=text, deadline=deadline, guard=guard)


async def announce_qq(supervisor, event, request, prepared, frozen):
    from harness.runtime.capability_adapters import get_broker
    if not get_broker(supervisor).policy.read()[0].progress_enabled:
        return True
    web = bool((prepared.get("web_plan") or {}).get("steps"))
    capability = prepared.get("capability_plan") or {}
    if not web and not capability.get("steps") and not capability.get("goal"):
        return True
    if request.transport != "onebot" or request.idle_intent is not None:
        return False
    if web and not (frozen.get("qq_web_capabilities") or {}).get("enabled"):
        return False
    if capability.get("steps") or capability.get("goal"):
        from harness.contracts.invocations import InvocationContext, CapabilityPlan
        authority = frozen.get("qq_runtime_capabilities") or {}
        summary = authority.get("summary") or {}
        if not summary.get("authorized") or summary.get("mode") != "enabled" or not authority.get("context"):
            return False
        broker = get_broker(supervisor)
        context = InvocationContext.model_validate(authority["context"])
        offers = await broker.discover(context, provider="server")
        if not any(o.ready for o in offers):
            return False
        plan = CapabilityPlan.model_validate(capability)
        for step in plan.steps:
            offer = next((o for o in offers if o.offer_id == step.offer_id and o.ready), None)
            if offer is None:
                return False
            try:
                broker.policy.validate(context, offer, step.arguments)
            except ValueError:
                return False
    from harness.runtime.qq_sources import verified_qq_source
    from harness.qq.direct_config import DirectQQSettings
    from harness.qq.direct_store import DirectStore
    from pathlib import Path
    verified = await asyncio.to_thread(verified_qq_source, request)
    settings = DirectQQSettings.read(Path(os.environ["NC_QQ_DIRECT_CONFIG"]))
    original = DirectStore(settings.state_db, settings.evidence_dir).get(request.trace.event_id)["event"]
    source = {key: original[key] for key in ("event_id", "group_id", "self_member_id", "member_id", "event_evidence_ref")}
    source["channel"] = "qq"
    if request.request_id is not None:
        from harness.qq.reply_requests import BINDING_FIELDS
        source["reply_request"] = {key: getattr(request, key) for key in BINDING_FIELDS}
    actions = (["查找资料"] if web else []) + (["查询服务器状态"] if capability.get("steps") else [])
    if capability.get("goal"):
        actions.append("安排后台任务")
    text = "我先" + "、".join(actions) + "，有结果后再告诉你。"
    def changed():
        return verified_qq_source(request)["digest"] != verified["digest"]
    return await get_progress(supervisor).announce("operation:" + prepared["prepare_id"], source=source,
        binding=[prepared["snapshot_hash"], source, verified["digest"]], text=text,
        deadline=request.deadline_at - timedelta(seconds=13), guard=changed)
