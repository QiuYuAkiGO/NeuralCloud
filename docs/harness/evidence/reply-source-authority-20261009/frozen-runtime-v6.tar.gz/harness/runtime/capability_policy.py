"""Fail-closed invocation ACL. Source identity is supplied by verified Runtime ingress."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Literal
from pydantic import BaseModel, ConfigDict, Field


STATUS_COMMANDS = (
    "uptime", "uname -a", "id", "whoami", "hostname", "date", "df -h", "free -m", "nproc",
    "systemctl is-active neuralcloud-runtime", "systemctl is-active neuralcloud-cognitive",
    "systemctl is-active neuralcloud-homeostasis",
)


class QQGrant(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)
    account_id: str = Field(pattern=r"^[0-9]+$")
    actor_id: str = Field(pattern=r"^[0-9]+$")
    conversation_id: str = Field(min_length=1)


class InvocationPolicy(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)
    version: Literal[1] = 1
    progress_enabled: bool = False
    sources: dict[str, Literal["legacy", "shadow", "enabled"]] = Field(default_factory=dict)
    qq_server_grants: tuple[QQGrant, ...] = ()
    server_read_commands: tuple[str, ...] = STATUS_COMMANDS

    def mode(self, source):
        # Existing calls use the broker; new conversational access is opt-in.
        return self.sources.get(source, "legacy" if source in {"qq", "chat"} else "enabled")

    def server_authorized(self, context):
        if context.source in {"goal", "autonomous"}:
            # Inherited QQ identity must not turn into an autonomous grant.
            if context.account_id is None:
                return context.autonomous
        elif context.source == "chat":
            return self.mode("chat") == "enabled"
        elif context.source != "qq":
            return False
        return (self.mode("qq") == "enabled" and bool(context.source_digest)
                and any((g.account_id, g.actor_id, g.conversation_id) ==
                        (context.account_id, context.actor_id, context.conversation_id)
                        for g in self.qq_server_grants))


class PolicyStore:
    def __init__(self, path: Path):
        self.path = path

    def read(self):
        if not self.path.exists():
            raw = b"{}"
        else:
            if self.path.is_symlink() or self.path.stat().st_size > 65536:
                raise ValueError("capability_policy_invalid")
            raw = self.path.read_bytes()
        policy = InvocationPolicy.model_validate_json(raw)
        # This policy can narrow the initial readonly surface, never expand it.
        if not set(policy.server_read_commands) <= set(STATUS_COMMANDS):
            raise ValueError("capability_policy_unsafe_command")
        return policy, hashlib.sha256(raw).hexdigest()

    def validate(self, context, offer, arguments=None):
        policy, revision = self.read()
        if context.policy_revision is not None and context.policy_revision != revision:
            raise ValueError("capability_policy_changed")
        if context.source == "goal" and context.account_id is not None and offer.capability_id != "server.observe.v1":
            raise ValueError("capability_not_authorized")
        if offer.channel in {"diary", "terminal", "vision"} and context.source != offer.channel:
            raise ValueError("capability_not_authorized")
        if offer.channel == "server":
            if not policy.server_authorized(context):
                raise ValueError("capability_not_authorized")
            if context.source in {"qq", "chat"} or context.account_id is not None:
                if offer.capability_id != "server.observe.v1":
                    raise ValueError("capability_not_authorized")
                if arguments is not None:
                    if (arguments.get("command") not in policy.server_read_commands or arguments.get("cwd") is not None
                            or set(arguments) - {"command", "timeout_seconds", "cwd"}
                            or type(arguments.get("timeout_seconds", 10)) is not int
                            or not 1 <= arguments.get("timeout_seconds", 10) <= 10):
                        raise ValueError("capability_command_not_allowed")
        return policy, revision

    def digest_context(self, context):
        return hashlib.sha256(json.dumps(context.model_dump(mode="json", exclude={"deadline"}),
                                         sort_keys=True).encode()).hexdigest()

    def project_offer(self, context, offer):
        policy, _ = self.validate(context, offer)
        if offer.channel == "server" and (context.source in {"qq", "chat"} or context.account_id is not None):
            from copy import deepcopy
            schema = deepcopy(offer.input_schema)
            schema["properties"]["command"]["enum"] = list(policy.server_read_commands)
            schema["properties"]["timeout_seconds"].update(default=10, maximum=10)
            return offer.model_copy(update={"input_schema": schema, "observation": None, "observation_refs": []})
        return offer
