"""One audited invocation boundary; domain ledgers remain the effect authorities."""
from __future__ import annotations

import asyncio
import hashlib
import json
import sqlite3
import threading
import weakref
from contextlib import contextmanager
from pathlib import Path

from harness.runtime.capability_policy import PolicyStore
from harness.runtime.models import utc_now


def _json(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


class InvocationIndex:
    def __init__(self, path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.lock = threading.RLock()
        with self.connect() as db:
            db.execute("""CREATE TABLE IF NOT EXISTS invocations(
                id TEXT PRIMARY KEY, fingerprint TEXT NOT NULL, source TEXT NOT NULL,
                event_id TEXT NOT NULL, goal_id TEXT, capability TEXT NOT NULL,
                provider TEXT NOT NULL, policy_revision TEXT NOT NULL, arguments_hash TEXT NOT NULL,
                created_at TEXT NOT NULL, updated_at TEXT NOT NULL, status TEXT NOT NULL,
                result_json TEXT, error_code TEXT)""")
            db.execute("CREATE INDEX IF NOT EXISTS invocation_event ON invocations(event_id)")
            db.execute("""CREATE TABLE IF NOT EXISTS denials(
                id INTEGER PRIMARY KEY, invocation_id TEXT, event_id TEXT, source TEXT,
                capability TEXT, at TEXT, code TEXT)""")
        self.path.chmod(0o600)

    @contextmanager
    def connect(self):
        db = sqlite3.connect(self.path, timeout=5)
        db.row_factory = sqlite3.Row
        try:
            with db:
                yield db
        finally:
            db.close()

    def get(self, identity):
        with self.lock, self.connect() as db:
            row = db.execute("SELECT * FROM invocations WHERE id=?", (identity,)).fetchone()
            return dict(row) if row else None

    def reserve(self, identity, fingerprint, context, offer, revision, arguments):
        with self.lock, self.connect() as db:
            db.execute("BEGIN IMMEDIATE")
            old = db.execute("SELECT * FROM invocations WHERE id=?", (identity,)).fetchone()
            if old:
                if old["fingerprint"] != fingerprint:
                    raise ValueError("capability_invocation_conflict")
                return dict(old)
            now = utc_now().isoformat()
            db.execute("INSERT INTO invocations VALUES (?,?,?,?,?,?,?,?,?,?,?,'started',NULL,NULL)",
                       (identity, fingerprint, context.source, context.event_id, context.goal_id,
                        offer.capability_id, offer.provider_id, revision,
                        hashlib.sha256(_json(arguments).encode()).hexdigest(), now, now))
            return None

    def finish(self, identity, status, result=None, error=None):
        with self.lock, self.connect() as db:
            db.execute("UPDATE invocations SET status=?,result_json=?,error_code=?,updated_at=? WHERE id=?",
                       (status, _json(result) if result is not None else None, error, utc_now().isoformat(), identity))

    def deny(self, identity, context, offer, error):
        code = str(error) if str(error).startswith("capability_") and len(str(error)) < 100 else type(error).__name__
        with self.connect() as db:
            db.execute("INSERT INTO denials(invocation_id,event_id,source,capability,at,code) VALUES(?,?,?,?,?,?)",
                (identity, context.event_id, context.source, offer.capability_id, utc_now().isoformat(), code))

    def list(self, *, event_id=None, goal_id=None, limit=50):
        clauses, values = [], []
        for name, value in (("event_id", event_id), ("goal_id", goal_id)):
            if value is not None:
                clauses.append(name + "=?")
                values.append(value)
        where = " WHERE " + " AND ".join(clauses) if clauses else ""
        with self.connect() as db:
            rows = db.execute("SELECT * FROM invocations" + where + " ORDER BY created_at DESC LIMIT ?",
                [*values, max(1, min(limit, 200))]).fetchall()
        result = []
        for row in rows:
            item = dict(row)
            data = json.loads(item.pop("result_json") or "{}")
            item["evidence_refs"] = data.get("evidence_refs", [])
            result.append(item)
        return result


class CapabilityBroker:
    def __init__(self, registry, state_dir):
        self.registry = registry
        self.index = InvocationIndex(Path(state_dir) / "capability-invocations.sqlite3")
        self.policy = PolicyStore(Path(state_dir) / "capability-policy.json")
        self.last_errors = {}
        self._locks = weakref.WeakValueDictionary()

    async def discover(self, context, *, provider=None, **options):
        if utc_now() >= context.deadline:
            raise TimeoutError("capability_deadline_expired")
        offers = []
        adapters = (self.registry.get(provider),) if provider else self.registry.adapters()
        for adapter in adapters:
            try:
                remaining = (context.deadline - utc_now()).total_seconds()
                async with asyncio.timeout(max(0, remaining)):
                    candidates = await adapter.discover(context, **options)
                for offer in candidates:
                    try:
                        offer = self.policy.project_offer(context, offer)
                    except ValueError:
                        continue
                    offers.append(offer)
                self.last_errors.pop(adapter.name, None)
            except Exception as exc:
                self.last_errors[adapter.name] = type(exc).__name__
        identities = [o.offer_id for o in offers]
        if len(identities) != len(set(identities)):
            raise ValueError("capability_duplicate_offer")
        return offers

    async def invoke(self, identity, context, offer, arguments, *, guard=None, **options):
        adapter = self.registry.get(offer.channel)
        def check():
            self.policy.validate(context, offer, arguments)
            if not offer.ready or offer.valid_until <= utc_now():
                raise ValueError("capability_offer_expired_or_unavailable")
            if utc_now() >= context.deadline:
                raise TimeoutError("capability_deadline_expired")
            if guard and guard():
                raise ValueError("capability_invocation_superseded")
            return False
        try:
            check()
        except (ValueError, TimeoutError) as exc:
            self.index.deny(identity, context, offer, exc)
            raise
        _, revision = self.policy.read()
        binding = [context.model_dump(mode="json", exclude={"deadline"}), offer.channel,
                   offer.capability_id, offer.provider_id, offer.body_instance_id, offer.activation_revision, offer.scope, arguments]
        fingerprint = hashlib.sha256(_json(binding).encode()).hexdigest()
        lock = self._locks.setdefault(identity, asyncio.Lock())
        async with lock:
            check()  # Revocation fences cached output as well as new effects.
            if not options.get("legacy"):
                async with asyncio.timeout(max(0, (context.deadline - utc_now()).total_seconds())):
                    current = await adapter.discover(context)
                binding_keys = ("offer_id", "capability_id", "provider_id", "body_instance_id", "scope", "activation_revision")
                if not any(candidate.ready and all(getattr(candidate, key) == getattr(offer, key)
                           for key in binding_keys) for candidate in current):
                    raise ValueError("capability_offer_binding_changed")
            previous = self.index.reserve(identity, fingerprint, context, offer, revision, arguments)
            if previous:
                if previous["status"] in {"started", "uncertain", "pending_approval"} and adapter.reconcile and not options.get("legacy"):
                    recovered = await adapter.reconcile(identity)
                    if recovered is not None:
                        check()
                        self.index.finish(identity, "completed", recovered.model_dump(mode="json"))
                        return recovered
                if previous["status"] != "completed":
                    raise ValueError("capability_invocation_" + previous["status"])
                result = json.loads(previous["result_json"])
                return adapter.result_type.model_validate(result) if adapter.result_type and not options.get("legacy") else result
            try:
                check()
                async with asyncio.timeout(max(0, (context.deadline - utc_now()).total_seconds())):
                    result = await adapter.execute(identity, context, offer, arguments, guard=check, **options)
                data = result.model_dump(mode="json") if hasattr(result, "model_dump") else result
                status = (data or {}).get("status", "completed")
                status = {"committed": "completed", "partial": "completed", "error": "failed",
                          "pending": "pending", "pending_approval": "pending_approval"}.get(status, status)
                self.index.finish(identity, status, data)
                return result
            except BaseException as exc:
                # Never replay an interrupted call; provider reconciliation owns uncertainty.
                status = "uncertain" if isinstance(exc, (asyncio.CancelledError, TimeoutError)) else "failed"
                self.index.finish(identity, status, error=type(exc).__name__)
                raise

    def reconcile(self, identity, *, status, result):
        if self.index.get(identity) is None:
            return
        self.index.finish(identity, status, result)

    def get_result(self, identity):
        return self.index.get(identity)

    def invoke_sync(self, identity, context, offer, arguments, *, guard=None, **options):
        """Synchronous domain adapters use the same durable reservation boundary."""
        adapter = self.registry.get(offer.channel)
        def check():
            self.policy.validate(context, offer, arguments)
            if utc_now() >= min(context.deadline, offer.valid_until) or not offer.ready:
                raise TimeoutError("capability_deadline_expired")
            if guard and guard():
                raise ValueError("capability_invocation_superseded")
            return False
        try:
            check()
        except (ValueError, TimeoutError) as exc:
            self.index.deny(identity, context, offer, exc)
            raise
        _, revision = self.policy.read()
        fingerprint = hashlib.sha256(_json([context.model_dump(mode="json", exclude={"deadline"}),
            offer.capability_id, offer.provider_id, offer.scope, arguments]).encode()).hexdigest()
        previous = self.index.reserve(identity, fingerprint, context, offer, revision, arguments)
        if previous:
            if previous["status"] != "completed":
                raise ValueError("capability_invocation_" + previous["status"])
            check()
            return json.loads(previous["result_json"]), True
        try:
            result = adapter.execute(identity, context, offer, arguments, guard=check, **options)
            check()
            self.index.finish(identity, "completed", result)
            return result, False
        except BaseException as exc:
            self.index.finish(identity, "uncertain", error=type(exc).__name__)
            raise
