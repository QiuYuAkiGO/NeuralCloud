"""Private domain operations registered alongside external provider adapters."""
from harness.contracts.capability_calls import CapabilityOffer


def local_offer(channel, capability, context):
    return CapabilityOffer(offer_id=capability, channel=channel, capability_id=capability,
        provider_id="builtin:" + channel, body_instance_id="local-domain",
        scope={"context_id": context.scope}, activation_revision="1",
        supported=True, available=True, ready=True, valid_until=context.deadline)
