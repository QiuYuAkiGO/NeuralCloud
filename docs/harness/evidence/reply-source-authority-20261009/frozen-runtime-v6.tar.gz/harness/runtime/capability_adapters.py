"""Composition root for built-in capabilities; no provider switches in the broker."""
from __future__ import annotations

from pathlib import Path

from harness.runtime.capability_registry import CapabilityAdapter, CapabilityRegistry
from harness.runtime.capability_broker import CapabilityBroker


def get_broker(supervisor, *, state_dir=None):
    existing = getattr(supervisor, "capability_broker", None)
    if existing is not None:
        return existing
    registry = CapabilityRegistry()

    def register(name, result_type=None):
        async def reconcile(identity):
            provider = getattr(supervisor, name, None)
            if provider is None or name not in {"web", "server"}:
                return None
            row = provider.calls.call(identity) if name == "web" else provider.calls.command(identity)
            if row is None or row["status"] != "completed" or not row.get("result"):
                return None
            return result_type.model_validate_json(row["result"])

        async def discover(context, **options):
            cap = getattr(supervisor, "capabilities", None)
            if context.source in {"autonomous", "goal"}:
                if cap is None:
                    return []
                return await getattr(cap, "_catalog_" + name)(
                    context_scope=context.scope, executing_action_id=options.get("executing_action_id"))
            provider = getattr(supervisor, name, None)
            if name not in {"web", "server"} or provider is None:
                return []
            return await provider.catalog(context.scope, autonomous=context.autonomous, deadline=context.deadline)

        async def execute(identity, context, offer, arguments, *, guard, legacy=None):
            if legacy is not None:
                row, selected, event, result = legacy
                await getattr(supervisor.capabilities, "dispatch_" + name)(row, selected, offer, event=event, result=result, invocation_guard=guard)
                return {key: row[key] for key in ("status", "evidence_refs", "channel_result", "server_call_id",
                                                 "web_call_id", "action_id") if key in row}
            provider = getattr(supervisor, name, None)
            if name not in {"web", "server"} or provider is None:
                raise ValueError("capability_requires_goal")
            if name == "server" and context.source in {"qq", "chat"}:
                arguments = {"timeout_seconds": 10, **arguments}
            return await provider.execute(identity, offer, arguments, deadline=context.deadline,
                                          autonomous=context.autonomous, guard=guard)
        from harness.contracts.capability_calls import CHANNEL_CAPABILITIES
        from harness.cognitive.action_planner import _INTENT_PROFILES
        registry.register(CapabilityAdapter(name, discover, execute, result_type,
            tuple(_INTENT_PROFILES if name == "desktop" else CHANNEL_CAPABILITIES.get(name, {})), reconcile))

    from harness.embodiment.web_contracts import WebResult
    from harness.embodiment.server_contracts import ServerCommandResult
    register("web", WebResult)
    register("server", ServerCommandResult)
    for name in ("board", "qq", "voice", "desktop"):
        register(name)
    from harness.runtime.models import EventDispatchResult, ActionExecution
    from harness.runtime.local_capabilities import local_offer
    def register_local(name, capability, result_type):
        async def discover(context, **options):
            return [local_offer(name, capability, context)] if context.source == name else []
        async def execute(identity, context, offer, arguments, *, guard, controller=None, event=None, process_seq=None):
            guard()
            if name == "diary":
                if controller is None or event.event_id != context.event_id or arguments != {"entry_id": event.payload["entry_id"]}:
                    raise ValueError("diary_invocation_binding_invalid")
                return await controller._dispatch(event, process_seq)
            if set(arguments) != {"action_id"} or identity != "terminal:" + arguments["action_id"]:
                raise ValueError("terminal_invocation_binding_invalid")
            return await supervisor.action_coordinator.execute(arguments["action_id"])
        registry.register(CapabilityAdapter(name, discover, execute, result_type, (capability,)))
    register_local("diary", "expression.diary.write.v1", EventDispatchResult)
    register_local("terminal", "desktop.terminal.action.v1", ActionExecution)
    registry.seal()
    state_dir = state_dir or getattr(supervisor, "state_dir", None)
    if state_dir is None:
        # Small controller rigs still use a private existing provider state directory.
        provider = getattr(supervisor, "web", None) or getattr(supervisor, "server", None)
        path = getattr(getattr(provider, "calls", None), "path", None)
        if path is None:
            raise ValueError("capability_broker_state_directory_missing")
        state_dir = Path(path).parent.parent
    broker = CapabilityBroker(registry, state_dir)
    supervisor.capability_broker = broker
    return broker
