"""Narrow factual guard for explicit capability/connection contradictions."""
import re


def correct_capability_contradiction(text, summary, receipt):
    if not summary:
        return None
    if summary.get("authorized") and receipt is None and re.search(r"现在(?:去|来)?查|这就.{0,8}查|稍后.{0,12}(?:告诉|结果)", text):
        return "当前具备服务器只读查询权限，但本轮没有执行查询，尚未取得运行状态。"
    denied = re.search(r"(?:没有|没|未)(?:连接|连到|连上).{0,12}服务器|(?:看不到|无法查看|不能查看|没有权限查看).{0,8}服务器", text)
    if summary.get("authorized") and summary.get("executable_offers") and denied:
        if receipt and receipt.get("status") == "completed" and receipt.get("exit_code") == 0:
            return "本次服务器只读查询已成功，结果已经返回。"
        return "当前会话有服务器只读查询权限；本轮尚未取得成功的查询结果。"
    if not summary.get("authorized") and (denied or re.search(r"查询成功|查到了.{0,12}服务器|服务器已经运行了", text)):
        return "当前会话没有服务器查询权限，不能提供本轮服务器状态。"
    return None
