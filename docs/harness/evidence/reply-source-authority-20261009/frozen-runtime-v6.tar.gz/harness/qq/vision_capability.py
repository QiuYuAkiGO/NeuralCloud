"""Cognitive-owned vision adapter; pixels and credentials never enter Runtime."""
from datetime import timedelta
from uuid import uuid4
import os
from pathlib import Path

from harness.contracts.invocations import InvocationContext
from harness.core.inference import TokenUsage
from harness.runtime.capability_broker import CapabilityBroker
from harness.runtime.capability_registry import CapabilityAdapter, CapabilityRegistry
from harness.runtime.local_capabilities import local_offer
from harness.runtime.models import utc_now


def invoke_vision(tool, request, *, deadline, trace, request_validator=None, client_factory=None):
    from harness.qq.telemetry import QQDeadline
    deadline = deadline or QQDeadline.after(tool.settings.llm_timeout)
    event_id = trace.event_id or "vision:" + uuid4().hex
    context = InvocationContext(source="vision", event_id=event_id,
        scope="qq:" + str(tool.group_id), deadline=utc_now() + timedelta(seconds=deadline.check()))
    offer = local_offer("vision", "vision.qq.inspect.v1", context)
    registry = CapabilityRegistry()
    def execute(identity, context, offer, arguments, *, guard):
        guard()
        result, usage = tool._invoke(request, deadline=deadline, trace=trace,
            request_validator=request_validator, client_factory=client_factory)
        return {"result": result, "usage": usage.model_dump(mode="json")}
    registry.register(CapabilityAdapter("vision", lambda context: [offer], execute,
        capability_ids=("vision.qq.inspect.v1",)))
    registry.seal()
    audit_dir = Path(os.environ["NC_RUNTIME_STATE_DIR"]) if os.environ.get("NC_RUNTIME_STATE_DIR") else (
        tool.config.image_cache_dir.parent / "capability-audit")
    broker = CapabilityBroker(registry, audit_dir)
    def guard():
        tool.check_attention()
        if request_validator is not None:
            request_validator()
        deadline.check()
        return False
    # Include image provenance; opaque image_1 alone is not a content binding.
    arguments = {"request": request.model_dump(mode="json") if request else None,
                 "images": [image.public() for image in tool.images]}
    value, replay = broker.invoke_sync("vision:" + event_id, context, offer, arguments, guard=guard)
    return value["result"], TokenUsage() if replay else TokenUsage.model_validate(value["usage"])
