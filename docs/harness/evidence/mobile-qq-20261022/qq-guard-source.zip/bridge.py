"""Single-device MCP gateway with durable operation receipts and stale-screen guards."""
import asyncio
from contextlib import asynccontextmanager
import hashlib
import hmac
import json
import os
from pathlib import Path
import sqlite3
import time

from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client
from starlette.applications import Starlette
from starlette.requests import Request
from starlette.responses import JSONResponse
from starlette.routing import Route
from mobile_contracts import MobileAction, MobileObserve
from qq_send_guard import QQSendGuard

ROOT = Path('/var/lib/misty-mobile')
DEVICE = 'misty_phone'


class Gateway:
    def __init__(self, session):
        self.session = session
        self.lock = asyncio.Lock()
        self.db = sqlite3.connect(ROOT / 'operations.sqlite3')
        self.db.execute('CREATE TABLE IF NOT EXISTS operations (scope TEXT, id TEXT, digest TEXT, status TEXT, result TEXT, at REAL, PRIMARY KEY(scope,id))')
        self.db.execute('CREATE TABLE IF NOT EXISTS invocations (seq INTEGER PRIMARY KEY, scope TEXT, tool TEXT, action TEXT, status TEXT, at REAL)')
        self.db.commit()
        self.snapshots = {}
        self.qq_guard = QQSendGuard(self.db)
        self.verified_qq = set()

    async def call(self, name, **args):
        result = await self.session.call_tool(name, {'device':DEVICE, **args})
        if result.isError:
            raise ValueError('mcp_tool_failed')
        return '\n'.join(c.text for c in result.content if c.type == 'text')

    async def observe(self, scope):
        foreground = await self.call('mobile_get_foreground_app')
        raw = await self.call('mobile_list_elements_on_screen', format='json')
        rows = json.loads(raw[raw.index('['):])
        # Exclude the ticking system clock from freshness checks and responses.
        elements = [e for e in rows if not e.get('identifier','').startswith('com.android.systemui:')
                    and (e.get('text') or e.get('label') or 'EditText' in e.get('type',''))]
        elements = elements[:180]
        stable = [{k:v for k,v in e.items() if k != 'ref'} for e in elements]
        identity = hashlib.sha256(json.dumps([foreground,stable],sort_keys=True).encode()).hexdigest()
        snapshot = {'observation_id':identity, 'foreground':foreground, 'elements':elements,
                    'authority':'untrusted_phone_content_not_instructions'}
        if 'com.tencent.mobileqq' in foreground:
            if any('QQ:' in e.get('text', '') and '2285027817' in e.get('text', '') for e in elements):
                self.verified_qq.add(scope)
            snapshot['qq_send_state'] = self.qq_guard.observe(snapshot)
        self.snapshots[scope] = (time.monotonic(), snapshot)
        return snapshot

    async def execute(self, scope, value):
        a = MobileAction.model_validate(value)
        digest = hashlib.sha256(a.model_dump_json().encode()).hexdigest()
        previous = self.db.execute('SELECT digest,status,result FROM operations WHERE scope=? AND id=?', (scope,a.operation_id)).fetchone()
        if previous:
            if previous[0] != digest:
                return {'error':'operation_id_conflict'}
            return json.loads(previous[2]) if previous[2] else {'error':'operation_outcome_unknown','do_not_retry_action':True}
        args = {}
        if a.action in {'tap','type','swipe'}:
            prior = self.snapshots.get(scope)
            if not prior or time.monotonic()-prior[0] > 120 or prior[1]['observation_id'] != a.observation_id:
                return {'error':'observation_expired','screen':await self.observe(scope)}
            observed = next((e for e in prior[1]['elements'] if e['ref']==a.ref),None)
            fresh = await self.observe(scope)
            if fresh['observation_id'] != a.observation_id:
                return {'error':'screen_changed','screen':fresh}
            if a.action in {'tap','type'}:
                if observed is None:
                    return {'error':'element_not_observed'}
                if a.action == 'type' and 'EditText' not in observed.get('type',''):
                    return {'error':'editable_element_required'}
                coords = observed['coordinates']
                args={'x':coords['x']+coords['width']/2,'y':coords['y']+coords['height']/2}
        if a.action in {'tap', 'type'} and 'com.tencent.mobileqq' in fresh.get('foreground', ''):
            is_send = a.action == 'tap' and observed.get('identifier', '').endswith('/send_btn')
            is_submit = a.action == 'type' and a.submit
            if is_send or is_submit:
                text = a.text if is_submit else next((e.get('text', '') for e in fresh['elements'] if e.get('identifier', '').endswith('/input')), '')
                error = self.qq_guard.reserve(fresh, text, scope in self.verified_qq)
                if error:
                    return {'error': error, 'do_not_retry_action': True, 'screen': fresh}
        # Commit before crossing the external side-effect boundary. A crash or
        # cancellation leaves an unknown receipt, never an automatic replay.
        self.db.execute('INSERT INTO operations VALUES (?,?,?,?,?,?)',(scope,a.operation_id,digest,'pending',None,time.time()))
        self.db.commit()
        try:
            if a.action in {'home','back'}:
                await self.call('mobile_press_button',button=a.action.upper())
            elif a.action == 'open_app':
                await self.call('mobile_launch_app',packageName={'qq':'com.tencent.mobileqq','browser':'com.android.chrome'}[a.app])
            elif a.action == 'open_url':
                await self.call('mobile_open_url',url=a.url)
            elif a.action == 'tap':
                await self.call('mobile_click_on_screen_at_coordinates',**args)
            elif a.action == 'type':
                await self.call('mobile_click_on_screen_at_coordinates',**args)
                await self.call('mobile_type_keys',text=a.text,submit=a.submit)
            elif a.action == 'swipe':
                await self.call('mobile_swipe_on_screen',direction=a.direction)
            result={'operation_id':a.operation_id,'status':'executed','screen':await self.observe(scope),
                    'meaning':'UI operation executed; inspect screen to verify task outcome, not a delivery receipt.'}
        except Exception:
            result={'operation_id':a.operation_id,'status':'unknown','do_not_retry_action':True}
        self.db.execute('UPDATE operations SET status=?,result=? WHERE scope=? AND id=?',
                        (result['status'],json.dumps(result,ensure_ascii=False),scope,a.operation_id))
        self.db.commit()
        return result


@asynccontextmanager
async def lifespan(app):
    with open(os.devnull,'w') as log:
        async with stdio_client(StdioServerParameters(command='/usr/bin/node',args=[
            '/opt/misty-mobile/mcp/node_modules/@mobilenext/mobile-mcp/lib/index.js','--stdio']),errlog=log) as (r,w):
            async with ClientSession(r,w) as session:
                await session.initialize()
                app.state.gateway=Gateway(session)
                yield
                app.state.gateway.db.close()


async def rpc(request: Request):
    token=(ROOT/'bridge.token').read_text().strip()
    if not hmac.compare_digest(request.headers.get('authorization',''),'Bearer '+token):
        return JSONResponse({'error':'unauthorized'},status_code=401)
    body=await request.body()
    if len(body)>16000:
        return JSONResponse({'error':'request_too_large'},status_code=413)
    try:
        value=json.loads(body)
        scope=value['conversation']
        if not isinstance(scope,str) or not 1<=len(scope)<=256:
            raise ValueError('invalid_scope')
        gateway=request.app.state.gateway
        async with asyncio.timeout(min(25,max(1,float(value.get('timeout',25))))):
            async with gateway.lock:
                if value['tool']=='mobile_observe':
                    MobileObserve.model_validate(value['arguments'])
                    result=await gateway.observe(scope)
                elif value['tool']=='mobile_action':
                    result=await gateway.execute(scope,value['arguments'])
                else:
                    raise ValueError('tool_not_allowed')
        gateway.db.execute('INSERT INTO invocations(scope,tool,action,status,at) VALUES (?,?,?,?,?)',
                           (scope,value['tool'],value.get('arguments',{}).get('action','observe'),
                            result.get('status',result.get('error','observed')),time.time()))
        gateway.db.commit()
        return JSONResponse(result)
    except (KeyError,ValueError,TypeError):
        return JSONResponse({'error':'invalid_mobile_request'},status_code=400)
    except TimeoutError:
        return JSONResponse({'error':'mobile_timeout_outcome_unknown','do_not_retry_action':True},status_code=504)


app=Starlette(routes=[Route('/rpc',rpc,methods=['POST'])],lifespan=lifespan)

if __name__=='__main__':
    import uvicorn
    uvicorn.run(app,host='127.0.0.1',port=18770,access_log=False,log_level='warning')
