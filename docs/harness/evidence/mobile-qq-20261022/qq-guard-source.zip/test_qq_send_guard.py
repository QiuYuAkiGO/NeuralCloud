import sqlite3
import unittest
from qq_send_guard import QQSendGuard

def screen(incoming='hello', outgoing=None, loading=False):
    rows = [{'text': '消息接收中...' if loading else '在线'}]
    for y, text, own in [(100, incoming, False), (400, outgoing, True)]:
        if text:
            rows += [{'label': '我的资料卡' if own else '秋的资料卡', 'coordinates': {'y': y+21}},
                     {'identifier': 'com.tencent.mobileqq:id/mjm', 'text': text, 'coordinates': {'y': y}}]
    return {'elements': rows}

class Tests(unittest.TestCase):
    def setUp(self):
        self.db = sqlite3.connect(':memory:')
        self.db.execute('CREATE TABLE operations(result TEXT,at REAL)')
        self.guard = QQSendGuard(self.db)
    def tearDown(self): self.db.close()
    def test_cross_turn_and_restart(self):
        self.assertIsNone(self.guard.reserve(screen(), 'reply', True))
        restarted = QQSendGuard(self.db)
        self.assertEqual(restarted.reserve(screen(), 'different wording', True), 'qq_previous_send_unverified')
        restarted.observe(screen(outgoing='reply'))
        self.assertEqual(restarted.reserve(screen(outgoing='reply'), 'another topic', True), 'qq_wait_for_new_incoming')
        self.assertIsNone(restarted.reserve(screen('new question', 'reply'), 'answer', True))
    def test_empty_loading_and_identity(self):
        self.assertEqual(self.guard.reserve(screen(), 'reply', False), 'qq_owner_profile_not_verified')
        self.assertEqual(self.guard.reserve(screen(loading=True), 'reply', True), 'qq_chat_not_ready')
        self.assertEqual(self.guard.reserve(screen(None), 'reply', True), 'qq_chat_not_ready')
    def test_incoming_cannot_confirm_send(self):
        self.guard.reserve(screen(), 'reply', True)
        self.guard.observe(screen('reply'))
        self.assertEqual(self.guard.load()['status'], 'pending')
    def test_recovered_old_incoming_does_not_rearm(self):
        self.guard.reserve(screen(), 'reply', True)
        self.guard.observe(screen('previously hidden incoming', 'reply'))
        self.assertEqual(self.guard.reserve(screen('previously hidden incoming', 'reply'), 'duplicate', True), 'qq_wait_for_new_incoming')
    def test_same_words_below_latest_reply_are_new(self):
        self.guard.reserve(screen(), 'reply', True)
        self.guard.observe(screen(outgoing='reply'))
        new = screen(outgoing='reply')
        for e in new['elements']:
            if e.get('text') == 'hello' or e.get('label') == '秋的资料卡': e['coordinates']['y'] += 600
        self.assertIsNone(self.guard.reserve(new, 'second reply', True))

if __name__ == '__main__': unittest.main()
