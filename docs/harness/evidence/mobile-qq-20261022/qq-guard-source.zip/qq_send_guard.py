"""Durable, cross-turn QQ send admission. UI submission is not delivery."""
import hashlib
import json
import time

def messages(screen):
    rows = screen.get('elements', [])
    avatars = [e for e in rows if '资料卡' in e.get('label', '')]
    found = []
    for e in rows:
        if not e.get('identifier', '').endswith('/mjm') or not e.get('text'):
            continue
        y = e.get('coordinates', {}).get('y', -10000)
        candidates = [a for a in avatars if abs(a.get('coordinates', {}).get('y', 10000)-y) < 100]
        if not candidates:
            continue
        avatar = min(candidates, key=lambda a: abs(a['coordinates']['y']-y))
        own = avatar.get('label') == '我的资料卡'
        # Text identity is deliberately conservative: scrolling old text or a
        # changed timestamp must never create a fresh send allowance.
        found.append({'own': own, 'text': e['text'], 'key': hashlib.sha256(e['text'].encode()).hexdigest(), 'y': y})
    return sorted(found, key=lambda m: m['y'])

class QQSendGuard:
    def __init__(self, db):
        self.db = db
        db.execute('CREATE TABLE IF NOT EXISTS qq_send_state (id INTEGER PRIMARY KEY CHECK(id=1), payload TEXT)')
        if not db.execute('SELECT 1 FROM qq_send_state WHERE id=1').fetchone():
            seen, last_text = set(), ''
            # Seed with existing audit evidence so deployment cannot re-arm old
            # messages. These fields are only from the dedicated owner phone.
            for (raw,) in db.execute('SELECT result FROM operations WHERE result IS NOT NULL ORDER BY at'):
                screen = json.loads(raw).get('screen', {})
                for m in messages(screen):
                    if not m['own']: seen.add(m['key'])
                for e in screen.get('elements', []):
                    if e.get('identifier', '').endswith('/input') and e.get('text'):
                        last_text = e['text']
            self.save({'seen': sorted(seen), 'last_text': last_text, 'status': 'previous_attempt_unverified' if last_text else 'ready'})

    def load(self):
        return json.loads(self.db.execute('SELECT payload FROM qq_send_state WHERE id=1').fetchone()[0])

    def save(self, value):
        self.db.execute('INSERT OR REPLACE INTO qq_send_state VALUES(1,?)', (json.dumps(value, ensure_ascii=False),))
        self.db.commit()

    def observe(self, screen):
        state = self.load()
        visible = messages(screen)
        matching = [i for i, m in enumerate(visible) if m['own'] and m['text'] == state['last_text']]
        if state['last_text'] and matching:
            # Recovered history can reveal incoming messages that were absent
            # while QQ was loading. Anything above our last bubble is old.
            state['seen'] = sorted(set(state['seen']) | {m['key'] for m in visible[:matching[-1]] if not m['own']})
            state['status'] = 'ui_submitted'; self.save(state)
        return {'last_text': state['last_text'], 'status': state['status'],
                'instruction': 'No repeated messages. Empty input is not delivery. Wait for new incoming content after a send; UI submission is not a read receipt.'}

    def reserve(self, screen, text, verified):
        if not verified:
            return 'qq_owner_profile_not_verified'
        rows = screen.get('elements', [])
        if any('消息接收中' in (e.get('text', '') + e.get('label', '')) for e in rows) or not messages(screen):
            return 'qq_chat_not_ready'
        state = self.load()
        if state['status'] in {'pending', 'previous_attempt_unverified'}:
            return 'qq_previous_send_unverified'
        visible = messages(screen)
        anchors = [i for i, m in enumerate(visible) if m['own'] and m['text'] == state['last_text']]
        incoming = []
        for i, m in enumerate(visible):
            if m['own']: continue
            m = dict(m)
            if anchors and i > anchors[-1]:
                # The same words (e.g. another hello) below our latest reply
                # are a new incoming message, unlike scrolling old history.
                m['key'] = hashlib.sha256((state['last_text'] + '\0' + m['text']).encode()).hexdigest()
            incoming.append(m)
        fresh = [m for m in incoming if m['key'] not in state['seen']]
        if state['last_text'] and not fresh:
            return 'qq_wait_for_new_incoming'
        if not text.strip():
            return 'qq_empty_message'
        state.update(last_text=text, status='pending', at=time.time(),
                     seen=sorted(set(state['seen']) | {m['key'] for m in incoming}))
        self.save(state)
        return None
