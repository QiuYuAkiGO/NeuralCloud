import asyncio,json,tempfile,unittest
from pathlib import Path
import bridge
from mobile_contracts import MobileAction


class GatewayTests(unittest.IsolatedAsyncioTestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        bridge.ROOT=Path(self.temp.name)
        self.gateway=bridge.Gateway(None)
        self.effects=[];self.label='original';self.cancel=False
        async def call(name,**args):
            if name=='mobile_get_foreground_app':return 'QQ'
            if name=='mobile_list_elements_on_screen':
                return 'Elements: '+json.dumps([{'ref':'@e1','type':'android.widget.EditText','text':self.label,'coordinates':{'x':1,'y':2,'width':3,'height':4}}])
            self.effects.append(name)
            if self.cancel:raise asyncio.CancelledError()
            return 'ok'
        self.gateway.call=call

    def tearDown(self):
        self.gateway.db.close();self.temp.cleanup()

    async def test_duplicate_action_has_one_effect(self):
        args={'operation_id':'one','action':'home'}
        first=await self.gateway.execute('turn',args)
        second=await self.gateway.execute('turn',args)
        self.assertEqual(first,second)
        self.assertEqual(len(self.effects),1)
        conflict=await self.gateway.execute('turn',{'operation_id':'one','action':'back'})
        self.assertEqual(conflict['error'],'operation_id_conflict')
        self.assertEqual(len(self.effects),1)

    async def test_changed_screen_cannot_receive_old_tap(self):
        s=await self.gateway.observe('turn');self.label='different recipient'
        result=await self.gateway.execute('turn',{'operation_id':'two','action':'tap','ref':'@e1','observation_id':s['observation_id']})
        self.assertEqual(result['error'],'screen_changed');self.assertFalse(self.effects)

    async def test_other_turn_cannot_use_observation(self):
        s=await self.gateway.observe('first')
        result=await self.gateway.execute('second',{'operation_id':'three','action':'type','ref':'@e1','text':'hello','observation_id':s['observation_id']})
        self.assertEqual(result['error'],'observation_expired');self.assertFalse(self.effects)

    async def test_interrupted_side_effect_is_not_replayed(self):
        self.cancel=True
        args={'operation_id':'four','action':'home'}
        with self.assertRaises(asyncio.CancelledError):await self.gateway.execute('turn',args)
        self.cancel=False
        result=await self.gateway.execute('turn',args)
        self.assertEqual(result['error'],'operation_outcome_unknown')
        self.assertEqual(len(self.effects),1)

    def test_unoffered_targets_rejected(self):
        for url in ['file:///etc/passwd','https://localhost/','https://bing.com.attacker.test/','https://user:secret@bing.com/']:
            with self.assertRaises(ValueError):MobileAction(operation_id='bad',action='open_url',url=url)
        with self.assertRaises(ValueError):MobileAction(operation_id='bad',action='open_app',app='shell')

if __name__=='__main__':unittest.main()
