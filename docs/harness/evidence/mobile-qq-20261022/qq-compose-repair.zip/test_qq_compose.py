import json, tempfile, unittest
from pathlib import Path
import bridge

class ComposeTests(unittest.IsolatedAsyncioTestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(); bridge.ROOT=Path(self.tmp.name)
        self.g=bridge.Gateway(None); self.scope='qq-group:1044946257:test'
        self.draft='old junk'; self.sent=[]; self.effects=[]; self.clear_ok=True
        async def call(name, **kw):
            if name=='mobile_get_foreground_app': return 'com.tencent.mobileqq'
            if name=='mobile_list_elements_on_screen': return json.dumps(self.rows())
            self.effects.append((name,kw))
            if name=='mobile_type_keys': self.draft+=kw['text']
            if name=='mobile_click_on_screen_at_coordinates' and kw['x']==510:
                self.sent.append(self.draft); self.draft=''
            return 'ok'
        async def clear():
            if self.clear_ok: self.draft=''
        self.g.call=call; self.g.clear_focused_input=clear
    def rows(self):
        rows=[{'ref':'title','identifier':'com.tencent.mobileqq:id/3o4','text':'⫰⫠PHANTOM-C'},
              {'ref':'count','identifier':'com.tencent.mobileqq:id/3o2','text':'(17)'},
              {'ref':'avatar','label':'member的资料卡','coordinates':{'y':100}},
              {'ref':'message','identifier':'com.tencent.mobileqq:id/mjm','text':'hello','coordinates':{'y':150}},
              {'ref':'input','identifier':'com.tencent.mobileqq:id/input','type':'android.widget.EditText','text':self.draft,'coordinates':{'x':0,'y':900,'width':20,'height':20}},
              {'ref':'send','identifier':'com.tencent.mobileqq:id/send_btn','text':'发送','coordinates':{'x':500,'y':900,'width':20,'height':20}}]
        if self.sent: rows += [{'ref':'own','label':'我的资料卡','coordinates':{'y':400}}, {'ref':'bubble','identifier':'com.tencent.mobileqq:id/mjm','text':self.sent[-1],'coordinates':{'y':421}}]
        return rows
    async def act(self, ident, action='type', text='new reply', submit=False):
        s=await self.g.observe(self.scope)
        a={'operation_id':ident,'action':action,'ref':'input' if action=='type' else 'send','observation_id':s['observation_id']}
        if action=='type': a.update(text=text,submit=submit)
        return await self.g.execute(self.scope,a)
    def tearDown(self): self.g.db.close(); self.tmp.cleanup()
    async def test_enter_rejected_before_reservation(self):
        r=await self.act('enter',submit=True)
        self.assertEqual(r['error'],'qq_enter_is_not_send'); self.assertEqual(self.draft,'old junk')
        self.assertEqual(self.g.group_guard.load()['status'],'ready'); self.assertFalse(self.effects)
    async def test_replace_and_clear(self):
        await self.act('one'); self.assertEqual(self.draft,'new reply')
        await self.act('two',text='replacement'); self.assertEqual(self.draft,'replacement')
        await self.act('clear',text=''); self.assertEqual(self.draft,''); self.assertFalse(self.sent)
    async def test_exact_verified_draft_and_send(self):
        await self.act('draft'); self.draft+=' foreign text'
        self.assertEqual((await self.act('bad','tap'))['error'],'qq_draft_not_verified')
        await self.act('fresh'); r=await self.act('send','tap')
        self.assertEqual(self.sent,['new reply']); self.assertEqual(r['message_submission'],'ui_submitted')
        self.scope='qq-group:1044946257:another-turn'
        await self.act('draft2'); self.assertEqual((await self.act('send2','tap'))['error'],'qq_wait_for_new_incoming')
        self.assertEqual(self.sent,['new reply'])
    async def test_failed_clear_does_not_append(self):
        self.clear_ok=False; r=await self.act('failure')
        self.assertEqual(r['status'],'unknown'); self.assertEqual(self.draft,'old junk'); self.assertFalse(self.sent)

if __name__=='__main__': unittest.main()
